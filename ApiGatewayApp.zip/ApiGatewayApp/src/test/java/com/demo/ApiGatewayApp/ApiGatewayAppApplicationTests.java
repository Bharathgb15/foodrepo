package com.demo.ApiGatewayApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewayAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
