package com.customer.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderBean {

    private Long id;
    private Long customerId;
    private Long dishId;
    private Timestamp orderDate;
    private double totalAmount;
    private int quantity;
    private String status;
}
