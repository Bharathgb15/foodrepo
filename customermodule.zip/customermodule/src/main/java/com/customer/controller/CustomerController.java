package com.customer.controller;

import com.customer.entity.Customer;
import com.customer.entity.Order;
import com.customer.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping("/register")
    public ResponseEntity<Customer> registerCustomer(@Valid @RequestBody Customer customer) {
        Customer registeredCustomer = customerService.registerCustomer(customer);
        return ResponseEntity.ok(registeredCustomer);
    }

    @GetMapping("/{customerId}/orders")
    public ResponseEntity<List<Order>> getCustomerOrders(@PathVariable Long customerId) {
        List<Order> orders = customerService.getOrdersByCustomerId(customerId);
        return ResponseEntity.ok(orders);
    }

    @PostMapping("/{customerId}/order")
    public ResponseEntity<Order> placeOrder(
            @PathVariable Long customerId,
            @RequestParam Long dishId,
            @RequestParam int quantity) {
        Order order = customerService.placeOrder(customerId, dishId, quantity);
        return ResponseEntity.ok(order);
    }

    @PutMapping("/order/{orderId}/cancel")
    public ResponseEntity<Void> cancelOrder(@PathVariable Long orderId) {
        customerService.cancelOrder(orderId);
        return ResponseEntity.noContent().build();
    }
}
