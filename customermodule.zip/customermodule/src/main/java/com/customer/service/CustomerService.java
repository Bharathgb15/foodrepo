package com.customer.service;

import com.customer.entity.Customer;
import com.customer.entity.Order;

import java.util.List;

public interface CustomerService {
    Customer registerCustomer(Customer customer);
    List<Order> getOrdersByCustomerId(Long customerId);
    Order placeOrder(Long customerId, Long dishId, int quantity);
    void cancelOrder(Long orderId);
}
