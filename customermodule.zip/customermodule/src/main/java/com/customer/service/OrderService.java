package com.customer.service;

import com.customer.entity.Order;

import java.util.List;

public interface OrderService {
    Order getOrderById(Long orderId);
    List<Order> getOrdersByCustomerId(Long customerId);
    Order placeOrder(Long customerId, Long dishId, int quantity);
    void cancelOrder(Long orderId);
}