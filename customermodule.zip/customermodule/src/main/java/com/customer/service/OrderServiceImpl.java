package com.customer.service;

import com.customer.entity.Customer;
import com.customer.entity.Order;
import com.customer.exception.OrderNotFoundException;
import com.customer.repository.CustomerRepository;
import com.customer.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
    }

    @Override
    public List<Order> getOrdersByCustomerId(Long customerId) {
        return orderRepository.findByCustomerId(customerId);
    }

    @Override
    public Order placeOrder(Long customerId, Long dishId, int quantity) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new OrderNotFoundException("Customer not found with id: " + customerId));

       
        double dishPrice = getDishPriceById(dishId); 

        double totalAmount = dishPrice * quantity;

        Order order = new Order();
        order.setCustomer(customer);
        order.setDishId(dishId);
        order.setQuantity(quantity);
        order.setTotalAmount(totalAmount);
        order.setOrderDate(new Timestamp(System.currentTimeMillis()));
        order.setStatus("Placed"); 

        return orderRepository.save(order);
    }

    @Override
    public void cancelOrder(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with id: " + orderId));
        
        orderRepository.delete(order);
    }

    
    private double getDishPriceById(Long dishId) {
        
        return 10.0; 
    }
}
